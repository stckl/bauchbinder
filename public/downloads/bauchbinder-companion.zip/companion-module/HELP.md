# Bauchbinder Companion Module

This module allows you to control the **Bauchbinder** lower thirds application.

## Configuration

*   **Host**: The IP address of the computer running Bauchbinder (default: 127.0.0.1)
*   **Port**: The port Bauchbinder is listening on (default: 5001)

## Actions

*   **Show Lower Third**: Display a lower third by its ID (1-99)
*   **Hide Active**: Hide the currently displayed lower third

## Variables

*   **\$(bauchbinder:active_id)**: The ID of the currently active lower third
*   **\$(bauchbinder:name_X)**: The name of lower third X
*   **\$(bauchbinder:title_X)**: The title of lower third X

## Feedbacks

*   **Lower Third Active Status**: Change button style when a specific lower third is visible
*   **Hide Button Active**: Change button style when NO lower third is visible
